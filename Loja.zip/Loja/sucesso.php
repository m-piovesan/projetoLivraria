<?php

include "header.php";
include "./verifica_cliente.php";

unset($_SESSION['carrinho']);
unset($_SESSION['total']);
?>

<h1>parabéns pela compra</h1>

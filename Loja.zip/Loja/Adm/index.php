<?php
    include "menu.php";
?>

        <!-- CONTEÚDO -->

            

            <h2>Área administrativa</h2>
            <p>Essa é a área administrativa da Livraria Books. Nela você pode fazer a gestão de cadastro dos produtos.</p>

            <div class="line"></div>            
            
    

        <!-- FIM CONTEÚDO -->

<?php
    include "rodape.php";
?>